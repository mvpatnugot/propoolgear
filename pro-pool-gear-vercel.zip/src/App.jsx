import { useState, useMemo } from "react";
import { motion } from "framer-motion";

const initialGear = [
  {
    name: "Shane Van Boening",
    fb: "https://facebook.com/",
    playingCue: "Cuetec SVB Series",
    shaft: "Cynergy Carbon Shaft",
    breakCue: "Cuetec Breach",
    case: "JB Case",
    chalk: "Taom",
    gloves: "—"
  },
  {
    name: "Joshua Filler",
    fb: "https://facebook.com/",
    playingCue: "Predator",
    shaft: "Revo Shaft",
    breakCue: "Predator BK Rush",
    case: "Predator Case",
    chalk: "Kamui",
    gloves: "—"
  }
];

export default function App() {
  const [gearData] = useState(initialGear);
  const [search, setSearch] = useState("");

  const filteredPlayers = useMemo(() => {
    return gearData.filter(player =>
      player.name.toLowerCase().includes(search.toLowerCase())
    );
  }, [gearData, search]);

  return (
    <div style={{ padding: 40 }}>
      <h1>Pro Pool Gear</h1>

      <input
        placeholder="Search players..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ marginBottom: 20, padding: 10 }}
      />

      <table width="100%" cellPadding="10">
        <thead>
          <tr>
            <th align="left">Player</th>
            <th align="left">Playing Cue</th>
            <th align="left">Chalk</th>
          </tr>
        </thead>
        <tbody>
          {filteredPlayers.map(player => (
            <tr key={player.name}>
              <td>
                <a href={player.fb} target="_blank">{player.name}</a>
              </td>
              <td>{player.playingCue}</td>
              <td>{player.chalk}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}